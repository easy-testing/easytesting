// Copyright 2011 Universidade Federal de Minas Gerais (UFMG)
//
// Implementação do TAD list utilizando Listas Encadeadas.
//
// Questão 1.
// Implemente em list.h e list.cc o TAD list, utilizando listas encadeadas.
//
// Questão 2.
// Escreva uam função "void Print(list& l)" que recebe uma lista como
// parâmetro e imprime na tela os elementos da lista no formato
// "[a1, a2, ..., an]".
//
// Questão 3: (DESAFIO)
// Escreva um programa que lê do teclado dois número naturais 'x' e 'd' e
// imprime na tela um numero 'y' que consiste no maior número que pode ser
// obtido removendo-se 'd' dígitos de 'x'. Por exemplo, para x = 6913274589 e
// d = 7, tem-se m = 989. Calcule a complexidade assintótica no pior caso
// do seu programa utilizando vetores e utilizando listas. 'x' pode ter entre
// 1 e 10^9 dígitos, ou seja, x nao pode ser representado por uma variável
// 'int'.

#include "list/src/list.h"

int main() {
  return 0;  // TODO.
}

