// Copyright 2011 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercícios sobre listas encadeadas - deque.
//
// Questão 1.
// Implemente em deque.h e deque.cc o TAD deque, utilizando listas ligadas.
//
// Questão 2.
// Escreva uma função "void Imprimir(deque& d)" que recebe como parâmetro um
// deque e imprime os elementos do deque na tela do computador.
//
// Questão 3.
// Escreva uma função "void MergeSort(deque& q)" que ordena os elementos de um
// deque em O(n*log n), onde n = q.size().
//
// Questão 4.
// Escreva um programa que lê um conjunto de números reais de um arquivo,
// Armazena-os em um deque e imprime os números ordenados na tela.

#include "deque/src/deque.h"

int main() {
  return 0;  // TODO.
}
