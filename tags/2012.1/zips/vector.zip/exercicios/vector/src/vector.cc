// Copyright 2011 Universidade Federal de Minas Gerais (UFMG)

#include "vector/src/vector.h"

#include <cstdlib>

vector::vector() {
  // TODO.
}

vector::vector(int n) {
  // TODO.
}

vector::vector(vector& v) {
  // TODO.
}

int vector::size() {
  return 0;  // TODO.
}

void vector::resize(int n) {
  // TODO.
}

VType& vector::operator[](int i) {
  return array_[0];  // TODO.
}

void vector::operator=(vector& v) {
  // TODO.
}

void vector::push_back(VType x) {
  // TODO.
}

void vector::pop_back() {
  // TODO.
}

void vector::insert(int index, VType x) {
  // TODO.
}

void vector::erase(int index) {
  // TODO.
}

vector::~vector() {
  // TODO.
}
