// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#include "matrizes/src/matrizes.h"

float MediaMatriz(int n, float a[][MAX]) {
  return 0;  // TODO.
}

void Identidade(int n, float a[][MAX]) {
  // TODO.
}

void Transposta(int n, float a[][MAX], float T[][MAX]) {
  // TODO.
}

bool Simetrica(int n, float a[][MAX]) {
  return true;  // TODO.
}

void SomaMatriz(int n, float a[][MAX], float b[][MAX], float s[][MAX]) {
  // TODO.
}

void MultMatriz(int n, float a[][MAX], float b[][MAX], float p[][MAX]) {
  // TODO.
}

void MostraMatriz(int n, int m, float a[][MAX]) {
  // TODO.
}
